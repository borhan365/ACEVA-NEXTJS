"use strict";
(() => {
var exports = {};
exports.id = 624;
exports.ids = [624];
exports.modules = {

/***/ 23:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Lp": () => (/* binding */ client)
});

// UNUSED EXPORTS: clientConfig, urlFor

;// CONCATENATED MODULE: external "@sanity/client"
const client_namespaceObject = require("@sanity/client");
var client_default = /*#__PURE__*/__webpack_require__.n(client_namespaceObject);
;// CONCATENATED MODULE: external "@sanity/image-url"
const image_url_namespaceObject = require("@sanity/image-url");
var image_url_default = /*#__PURE__*/__webpack_require__.n(image_url_namespaceObject);
;// CONCATENATED MODULE: ./lib/client.js


const clientConfig = {
    projectId: "b5p4p9u6",
    dataset: "production"
};
const client = client_default()({
    projectId: clientConfig.projectId,
    dataset: clientConfig.dataset,
    apiVersion: "2023-01-17",
    token: "sk9mBKca1xR1vhL4OcLeG6mPuej7ucvs4ZOFu6Js5j6bZJbsEewhy8T5zjQpE71MkbcdVEJpUx8AY13c5AQnQv5zNtbAeZznu1OZxRENnOnznBhqMk1Pdwn2Yo6tMzoOcMdbDy2ENz0rurdtC0AuwwrfkZexml8Y6CQXCaDKUbAO49CfleNU",
    useCdn: true
});
const builder = image_url_default()(client);
const urlFor = (source)=>builder.image(source);


/***/ }),

/***/ 624:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "loadData": () => (/* binding */ loadData)
/* harmony export */ });
/* harmony import */ var _lib_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(23);

async function loadData() {
    const query = `{
    "footers": *[_type == "footer"] | order(publishedDate desc) {_id, publishedDate, title, slug, description, mainImage, _createdAt, categories[], body, author->},
    "total": count(*[_type == "footer"])
  }`;
    const { footers  } = await _lib_client__WEBPACK_IMPORTED_MODULE_0__/* .client.fetch */ .Lp.fetch(query);
    return {
        footers
    };
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(624));
module.exports = __webpack_exports__;

})();