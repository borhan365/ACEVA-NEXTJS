import '../styles/MainChat.css'
import '../styles/Responsive.css'

export default function App({ Component, pageProps }) {
  return <Component {...pageProps} />
}
